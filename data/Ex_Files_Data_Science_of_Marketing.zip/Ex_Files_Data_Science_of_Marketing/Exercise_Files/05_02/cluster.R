# Cluster Analysis 

# Connect to our case study data
myClusterData <- read.csv("~/Desktop/Exercise_Files/05_02/cluster-r.csv")

# Review our data

# Standardize the data

# Run kmeans on our standardized data

# Load in our cluster library 

# Visualize our clusters

# Summarize our data
