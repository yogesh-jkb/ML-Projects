# Connect to our data
myRegressionData <- read.csv("~/Desktop/Exercise_Files/03_02/regression-r.csv")

# Plot our data (broadcast & sales)

# Fit a line

# Visualize the line

# Show our coefficients 