# import csv file 

# get a quick snapshot of your data

# shift the names to each row

# review that transformation 

# transform into a matrix 

# generate our heatmap